#include <iostream>
#include <cstdlib>
using namespace std;

int main() {

    
    float b, h, area;

    
    cout << "AREA DEL PARALELOGRAMO" << endl << endl;
    cout << "Digite la base (b): ";
    cin >> b;
    cout << "Digite la altura (h): ";
    cin >> h;

    
    area = b * h;

    
    system("cls");
    cout << "Figura: PARALELOGRAMO" << endl;
    cout << "El area es: " << area << endl << endl;

    cout << "Desarrollado por: Brayan Camilo Castiblanco" << endl;

    system("pause");
    return 0;
}
