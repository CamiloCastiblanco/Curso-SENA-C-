#include <iostream>
#include <cstdlib>
using namespace std;

int main() {

    float a, b, area;
    
    cout << "AREA DEL RECTANGULO" << endl << endl;
    cout << "Digite el lado a (base): ";
    cin >> a;
    cout << "Digite el lado b (altura): ";
    cin >> b;
   
    area = a * b;
  
    system("cls");
    cout << "Figura: RECTANGULO" << endl;
    cout << "El area es: " << area << endl << endl;
  
    cout << "Desarrollado por: Brayan Camilo Castiblanco" << endl;

    system("pause");
    return 0;
}
