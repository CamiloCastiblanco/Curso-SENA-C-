#include <iostream>
#include <cstdlib>
using namespace std;

int main() {

    
    float D, d, area;

    
    cout << "AREA DEL ROMBO" << endl << endl;
    cout << "Digite la diagonal mayor (D): ";
    cin >> D;
    cout << "Digite la diagonal menor (d): ";
    cin >> d;

    
    area = (D * d) / 2;

    
    system("cls");
    cout << "Figura: ROMBO" << endl;
    cout << "El area es: " << area << endl << endl;

    cout << "Desarrollado por: Brayan Camilo Castiblanco" << endl;

    system("pause");
    return 0;
}
