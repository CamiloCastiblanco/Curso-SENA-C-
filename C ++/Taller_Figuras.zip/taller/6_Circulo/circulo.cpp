#include <iostream>
#include <cstdlib>
using namespace std;

int main() {
    
    const float PI = 3.14159265;
    float r, area;
    
    cout << "AREA DEL CIRCULO" << endl << endl;
    cout << "Digite el radio (r): ";
    cin >> r;
    
    area = PI * r * r;
    
    system("cls");
    cout << "Figura: CIRCULO" << endl;
    cout << "El area es: " << area << endl << endl;

    cout << "Desarrollado por: Brayan Camilo Castiblanco" << endl;

    system("pause");
    return 0;
}
