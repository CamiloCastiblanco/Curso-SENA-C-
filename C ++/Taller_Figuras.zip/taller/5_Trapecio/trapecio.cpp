#include <iostream>
#include <cstdlib>
using namespace std;

int main() {

    
    float B, b, h, area;
    
    cout << "AREA DEL TRAPECIO" << endl << endl;
    cout << "Digite la base mayor (B): ";
    cin >> B;
    cout << "Digite la base menor (b): ";
    cin >> b;
    cout << "Digite la altura (h): ";
    cin >> h;
    
    area = ((B + b) * h) / 2;

    system("cls");
    cout << "Figura: TRAPECIO" << endl;
    cout << "El area es: " << area << endl << endl;

    cout << "Desarrollado por: Brayan Camilo Castiblanco" << endl;

    system("pause");
    return 0;
}
